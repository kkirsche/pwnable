from pwnable.core.base import Pwnable


def cli():
    cli = Pwnable()
    cli.cmdloop()
